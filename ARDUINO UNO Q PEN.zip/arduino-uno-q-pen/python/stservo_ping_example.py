#!/usr/bin/env python
# SPDX-FileCopyrightText: Copyright (C) ARDUINO SRL (http://www.arduino.cc)
#
# SPDX-License-Identifier: MPL-2.0

"""
Simple ST servo ping test for Arduino UNO Q.

Run this on the MPU (Python side) to verify that the board can talk
to the ST servos over USB using the STservo_sdk library.

For now it only prints information about each servo ID on the console.
"""

import os

from STservo_sdk import PortHandler, sts, COMM_SUCCESS

DEFAULT_BAUDRATE = 1_000_000
# Adjust this to match the USB-to-serial adapter used for the servos.
# You can also override it with the STSERVO_PORT environment variable.
DEFAULT_DEVICE = os.getenv("STSERVO_PORT", "/dev/ttyACM0")

# Default IDs to ping (you can override with STSERVO_IDS env var)
DEFAULT_IDS = (1, 2, 3, 4, 5, 254)


def open_bus(device: str = DEFAULT_DEVICE, baudrate: int = DEFAULT_BAUDRATE):
    """Open the serial port and return (portHandler, sts_handler)."""
    port = PortHandler(device)

    if not port.openPort():
        print(f"[STServo] Failed to open port {device}")
        return None, None

    if not port.setBaudRate(baudrate):
        print(f"[STServo] Failed to set baudrate {baudrate} on {device}")
        port.closePort()
        return None, None

    print(f"[STServo] Port {device} open @ {baudrate} bps")
    handler = sts(port)
    return port, handler


def ping_ids(servo_ids=DEFAULT_IDS, device=DEFAULT_DEVICE, baudrate=DEFAULT_BAUDRATE):
    """
    Ping each servo ID and print the result.

    For each ID it prints either the model number (if a servo responds)
    or that there was no response.
    """
    port, handler = open_bus(device, baudrate)
    if port is None or handler is None:
        return

    try:
        for sid in servo_ids:
            scs_model_number, scs_comm_result, scs_error = handler.ping(sid)
            if scs_comm_result == COMM_SUCCESS:
                print(
                    f"[STServo] ID={sid:3d} ping OK, model={scs_model_number}, error={scs_error}"
                )
            else:
                print(
                    f"[STServo] ID={sid:3d} no response (result={scs_comm_result})"
                )
    finally:
        port.closePort()
        print("[STServo] Port closed")


if __name__ == "__main__":
    ids_env = os.getenv("STSERVO_IDS")
    if ids_env:
        try:
            ids = tuple(int(x.strip()) for x in ids_env.split(",") if x.strip())
        except ValueError:
            ids = DEFAULT_IDS
    else:
        ids = DEFAULT_IDS

    print(f"[STServo] Using device={DEFAULT_DEVICE}, ids={ids}")
    ping_ids(ids)

